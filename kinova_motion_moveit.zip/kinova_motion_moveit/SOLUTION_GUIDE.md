# 目标位姿控制程序完整解决方案

## 问题分析
您遇到的问题是：
1. **需要构建工作空间** - 是的，ROS2程序需要在正确配置的工作空间中运行
2. **关节状态超时** - 这表明ROS2节点未正常运行或机械臂驱动未启动

## 解决方案概览

### 📁 文件结构
```
kinova_motion_moveit/
├── motion_target_pose.py          # 主程序 - 目标位姿控制
├── test_target_pose.py            # 测试版本 - 不依赖ROS2
├── setup_windows_environment.bat  # Windows环境配置脚本
├── run_target_pose.bat            # Windows启动脚本
├── README_TARGET_POSE.md          # 详细使用说明
├── SOLUTION_GUIDE.md              # 本文档
└── [现有程序文件]
```

## 🚀 快速开始

### 步骤1: 环境准备
```cmd
# 1. 打开命令提示符（管理员权限）
# 2. 配置ROS2环境
call C:\opt\ros\humble\setup.bat

# 3. 启动ROS2守护进程
ros2 daemon start

# 4. 运行环境配置脚本
setup_windows_environment.bat
```

### 步骤2: 测试程序逻辑（可选）
```cmd
# 运行测试版本，验证程序逻辑
python test_target_pose.py
```

### 步骤3: 启动机械臂节点
在**另一个终端**中启动机械臂控制：
```cmd
call C:\opt\ros\humble\setup.bat
# 这里启动您的机械臂驱动节点
# 具体命令取决于您的机器人配置
```

### 步骤4: 运行主程序
```cmd
# 方法1: 使用启动脚本
run_target_pose.bat

# 方法2: 直接运行
python motion_target_pose.py
```

## 🔧 详细故障排除

### 问题1: "关节状态超时"

#### 🔍 诊断步骤
```cmd
# 检查ROS2是否正常运行
ros2 node list

# 检查关节状态话题
ros2 topic list | findstr joint_states

# 检查MoveIt节点
ros2 node list | findstr move_group
```

#### ✅ 解决方案
1. **确保ROS2环境正确**：
   ```cmd
   call C:\opt\ros\humble\setup.bat
   ros2 daemon start
   ```

2. **启动机械臂驱动**：
   - 需要根据您的具体机器人配置启动驱动节点
   - 通常涉及启动URDF描述、机器人状态发布器、MoveIt规划器等

3. **检查网络连接**（如果使用分布式ROS2）：
   ```cmd
   ROS_DOMAIN_ID=your_domain_id
   ```

### 问题2: 依赖包缺失

#### 🔍 诊断步骤
```cmd
# 检查Python包
python -c "import pymoveit2"
python -c "import rclpy"
python -c "import numpy"
```

#### ✅ 解决方案
```cmd
# 安装缺失的包
pip install numpy pymoveit2

# 或使用ROS2包管理器
pip install rclpy geometry_msgs sensor_msgs
```

### 问题3: 工作空间配置错误

#### 🔍 诊断步骤
- 检查是否有`setup.py`文件
- 检查ROS2包路径是否正确

#### ✅ 解决方案
如果您有完整的工作空间：
```cmd
# 进入工作空间
cd /path/to/your/workspace

# 编译工作空间
colcon build

# 设置环境
source install/setup.bash
```

## 📋 程序功能特性

### ✨ 核心功能
- [x] **直接位姿输入**: 输入(x,y,z,thetax,thetay,thetaz)控制机械臂
- [x] **双臂支持**: 可控制左臂、右臂或双臂同时
- [x] **工作空间检查**: 自动验证目标位置是否在机械臂工作范围内
- [x] **坐标转换**: 自动将欧拉角转换为四元数
- [x] **错误处理**: 完善的输入验证和错误提示

### 🛡️ 安全特性
- [x] **碰撞检测**: 检查基座附近不可达区域
- [x] **工作空间限制**: 基于EA200机械臂规格的严格边界检查
- [x] **参数验证**: 输入参数完整性和有效性检查

## 📊 使用示例

### 示例1: 左臂简单位置
```
选择机械臂: 1
输入参数:
  X: 0.3, Y: 0.2, Z: 0.4
  thetax: 0, thetay: 0, thetaz: 0
```

### 示例2: 右臂复杂姿态
```
选择机械臂: 2  
输入参数:
  X: -0.3, Y: -0.2, Z: 0.5
  thetax: 45, thetay: 30, thetaz: 90
```

### 示例3: 双臂协同
```
选择机械臂: 3
左臂: X=0.3, Y=0.2, Z=0.4, 姿态=0,0,0
右臂: X=-0.3, Y=-0.2, Z=0.4, 姿态=0,0,0
```

## 🔄 程序流程图

```
开始
  ↓
选择机械臂 (左/右/双臂)
  ↓
等待ROS2连接
  ↓
获取当前关节状态
  ↓
输入目标位姿参数
  ↓
验证工作空间限制
  ↓
欧拉角转四元数
  ↓
发送运动指令
  ↓
等待运动完成
  ↓
显示运动结果
  ↓
结束
```

## 🛠️ 技术细节

### 坐标系定义
- **基座坐标系**: 机械臂安装基座
- **旋转顺序**: ZYX (先绕Z轴，再绕Y轴，最后绕X轴)
- **单位**: 位置-米，角度-度

### 工作空间限制 (EA200机械臂)
- **水平距离**: 最大0.895米
- **垂直范围**: -0.15米 到 1.1米  
- **基座安全区**: 半径0.1米内，高度<0.2米为危险区域

### 四元数转换算法
使用标准ZYX欧拉角到四元数转换：
```
qw = cos(roll/2)*cos(pitch/2)*cos(yaw/2) + sin(roll/2)*sin(pitch/2)*sin(yaw/2)
qx = sin(roll/2)*cos(pitch/2)*cos(yaw/2) - cos(roll/2)*sin(pitch/2)*sin(yaw/2)
qy = cos(roll/2)*sin(pitch/2)*cos(yaw/2) + sin(roll/2)*cos(pitch/2)*sin(yaw/2)
qz = cos(roll/2)*cos(pitch/2)*sin(yaw/2) - sin(roll/2)*sin(pitch/2)*cos(yaw/2)
```

## 📞 技术支持

### 常用调试命令
```cmd
# 查看ROS2节点图
ros2 run rqt_graph rqt_graph

# 监控关节状态
ros2 topic echo /joint_states

# 检查TF变换
ros2 run tf2_tools tf2_echo base_link tool_frame

# 查看MoveIt服务
ros2 service list | grep moveit
```

### 日志和错误信息
- 程序会输出详细的运行状态
- 所有关键步骤都有进度提示
- 错误信息包含具体的解决建议

## 📈 后续改进计划

1. **图形界面**: 添加GUI界面，更直观的参数输入
2. **轨迹录制**: 记录和重放机械臂运动轨迹
3. **碰撞检测**: 集成更精确的碰撞检测算法
4. **路径规划**: 集成避障路径规划功能
5. **远程控制**: 支持网络远程控制

---

**注意**: 本解决方案基于您提供的代码结构和配置。如果您的实际硬件配置或ROS2环境有所不同，请相应调整相关配置文件和启动脚本。