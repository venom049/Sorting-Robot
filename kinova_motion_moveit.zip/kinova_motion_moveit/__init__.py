"""
Kinova双机械臂运动控制功能包
"""

__version__ = "0.0.0"